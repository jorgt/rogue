define([], function() {

	return {
		font: 12,
		square: 15,
		debug: true
	};
});